// wordModel.js
import dotenv from "dotenv";

dotenv.config();


// const mongoose = require('mongoose');

// const wordSchema = new mongoose.Schema({
  
//   _id:String,
//   WORD_association:String,
//   WORD_person:String,
//   BRAND_association:String,
//   BRAND_name:String,
//   PERSON_association:String,
//   PERSON_relationship:String,
//   PERSON_gender:String,
//   SELF_association:String,
//   QUESTION_trust:Number,
//   languages:String,
//   age:Number,
//   sex:String,
//   ethnicity:String,
//   country_of_birth:String,
//   country_of_residence:String,
//   nationality:String,
//   first_language:String,
//   employment:String

// });

// module.exports = mongoose.model('Word', wordSchema);
